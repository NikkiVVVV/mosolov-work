"""Portable local animation player. Python 3.9+, no package installation."""
import argparse
import io
import json
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import ipaddress
from pathlib import Path
import socket
import subprocess
import sys
import threading
from urllib.parse import parse_qs, unquote, urlencode, urlsplit
import webbrowser

ROOT = Path(__file__).resolve().parent
PLAYER = ROOT / 'player'
sys.path.insert(0, str(ROOT / 'vendor'))
import qrcode
import qrcode.image.svg


def network_ip():
    if sys.platform == 'darwin':
        for interface in ('en0', 'en1'):
            try:
                value = subprocess.check_output(['ipconfig', 'getifaddr', interface], text=True, stderr=subprocess.DEVNULL, timeout=2).strip()
                if ipaddress.ip_address(value).is_private:
                    return value
            except (OSError, ValueError, subprocess.SubprocessError):
                pass
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(('192.0.2.1', 1))
            value = sock.getsockname()[0]
        if not ipaddress.ip_address(value).is_loopback:
            return value
    except OSError:
        pass
    raise RuntimeError('Нет адреса локальной сети')


class Handler(SimpleHTTPRequestHandler):
    extensions_map = dict(SimpleHTTPRequestHandler.extensions_map, **{'.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8'})

    def send_data(self, data, content_type):
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urlsplit(self.path)
        if parsed.path == '/api/status':
            self.send_data(json.dumps({'app': 'animation-player-shell', 'version': '0.1.0', 'folder': str(ROOT), 'port': self.server.server_port}).encode(), 'application/json; charset=utf-8')
            return
        if parsed.path in ('/api/network', '/api/qr.svg'):
            try:
                origin = f'http://{network_ip()}:{self.server.server_port}'
                if parsed.path == '/api/network':
                    self.send_data(json.dumps({'origin': origin}).encode(), 'application/json; charset=utf-8')
                else:
                    query = parse_qs(parsed.query)
                    allowed = ('animation', 'version', 'theme', 'mode', 'x', 'y', 'scale')
                    values = {key: query[key][0][:100] for key in allowed if key in query}
                    values['preview'] = '1'
                    image = qrcode.make(origin + '/?' + urlencode(values), image_factory=qrcode.image.svg.SvgPathFillImage, border=4)
                    buffer = io.BytesIO()
                    image.save(buffer)
                    self.send_data(buffer.getvalue(), 'image/svg+xml')
            except RuntimeError:
                self.send_error(503, 'Нет адреса локальной сети')
            return
        super().do_GET()

    def translate_path(self, path):
        path = unquote(urlsplit(path).path).lstrip('/')
        target = (PLAYER / path).resolve()
        if not target.is_relative_to(PLAYER.resolve()):
            return str(ROOT / '__missing__')
        return str(target)

    def list_directory(self, path):
        self.send_error(404)
        return None

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()


def main():
    parser = argparse.ArgumentParser(description='Локальная оболочка плеера анимаций')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--host', default='0.0.0.0')
    parser.add_argument('--open', action='store_true', dest='open_browser')
    parser.add_argument('--no-browser', action='store_false', dest='open_browser')
    parser.set_defaults(open_browser=False)
    args = parser.parse_args()
    if not 0 <= args.port <= 65535:
        parser.error('Порт должен быть от 0 до 65535')
    server = None
    ports = [0] if args.port == 0 else range(args.port, min(args.port + 20, 65536))
    for port in ports:
        try:
            server = ThreadingHTTPServer((args.host, port), Handler)
            break
        except OSError as error:
            if getattr(error, 'errno', None) not in (48, 98, 10048):
                raise
    if server is None:
        raise SystemExit('Не удалось выбрать свободный порт. Укажите --port с другим номером.')
    url = f'http://127.0.0.1:{server.server_port}'
    print(f'Плеер: {url}', flush=True)
    print(f'Папка: {ROOT}', flush=True)
    print('Остановить сервер: Ctrl+C', flush=True)
    if args.open_browser:
        threading.Timer(0.4, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
