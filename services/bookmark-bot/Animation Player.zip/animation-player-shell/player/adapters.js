const clamp = v => Math.max(0, Math.min(1, v));
const smooth = p => p*p*p*(10+p*(-15+6*p));
export const easings = {
  smooth: {label:'Мягкая', at:smooth, curve:[.45,0,.55,1]},
  linear: {label:'Линейная', at:p=>p, curve:[0,0,1,1]},
  in: {label:'Разгон', at:p=>p*p*p, curve:[.55,0,1,.45]},
  out: {label:'Торможение', at:p=>1-(1-p)**3, curve:[0,.55,.45,1]},
  inout: {label:'Разгон и торможение', at:p=>p<.5?4*p**3:1-(-2*p+2)**3/2, curve:[.65,0,.35,1]}
};
export const fields = {
  hold:{label:'Пауза до движения', unit:'мс', min:0,max:4000,step:50},
  duration:{label:'Длительность движения', unit:'мс', min:200,max:4000,step:50},
  tail:{label:'Пауза после', unit:'мс', min:0,max:2000,step:50},
  fade:{label:'Длительность фейда', unit:'мс', min:0,max:4000,step:50},
  opacity:{label:'Непрозрачность в конце', unit:'%', min:0,max:100,step:1},
  x:{label:'Смещение по X', unit:'px', min:0,max:1600,step:4},
  y:{label:'Смещение по Y', unit:'px', min:-400,max:600,step:4},
  scale:{label:'Масштаб в конце', unit:'%', min:40,max:140,step:1},
  rotate:{label:'Поворот', unit:'°', min:-30,max:30,step:1}
};
function fitScene(w, size){
  const doc=w.document;
  const style=doc.createElement('style');
  style.textContent=`html,body{margin:0!important;padding:0!important;width:100%!important;height:100%!important;overflow:hidden!important;background:transparent!important}.preview-header,.playback,.chapters,nav{display:none!important}.preview-app{display:block!important;margin:0!important;padding:0!important;min-height:0!important;background:transparent!important}.stage-shell{position:absolute!important;left:50%!important;top:50%!important;margin:0!important;padding:0!important;width:${size[0]}px!important;height:${size[1]}px!important;transform:translate(-50%,-50%) scale(var(--studio-fit))!important;overflow:visible!important;background:transparent!important;box-shadow:none!important;border:0!important;border-radius:0!important}#film{width:${size[0]}px!important;height:${size[1]}px!important;transform:none!important;margin:0!important;background:transparent!important}#animation,#canvas{position:absolute!important;left:50%!important;top:50%!important;transform:translate(-50%,-50%) scale(var(--studio-fit))!important;margin:0!important;padding:0!important;width:${size[0]}px!important;height:${size[1]}px!important;background:transparent!important}#animation svg,#canvas svg{width:100%!important;height:100%!important}#animation svg,#canvas svg{max-width:100%;max-height:100%;object-fit:contain}`;
  doc.head.append(style);
  return zoom => doc.documentElement.style.setProperty('--studio-fit', String(Math.min(w.innerWidth/size[0],w.innerHeight/size[1])*zoom));
}
export async function connect(frame, version){
  const w=frame.contentWindow;
  const start=performance.now();
  while(!(w.__ready || w.ready)){
    if(performance.now()-start>15000) throw Error('Сцена не ответила. Попробуйте загрузить её ещё раз.');
    await new Promise(r=>setTimeout(r,50));
  }
  w.demo?.pause();w.anim?.pause();
  const isLottie=version.adapter==='lottie';
  if(isLottie && !w.anim) throw Error('В этой сцене не найден Lottie-плеер.');
  if(!isLottie && typeof w.renderAt!=='function') throw Error('Для сцены нужен адаптер с renderAt(time).');
  const duration=isLottie?w.anim.getDuration(false):version.duration;
  const symbols=isLottie;
  const sourceSteps=version.steps || Array.from({length:symbols?3:4},(_,i)=>[i*duration/(symbols?3:4),symbols?['Подарок','Рубль','Процент'][i]:`Карточка ${i+1}`]);
  const steps=sourceSteps.map(([at,title],i)=>({id:String(i),title,start:at,duration:(sourceSteps[i+1]?.[0]??duration)-at}));
  const size=isLottie?[w.anim.animationData.w,w.anim.animationData.h]:(version.size||[1080,1080]);
  const fit=fitScene(w,size);
  return {editable:false,steps, duration:()=>duration, render:t=>isLottie?w.anim.goToAndStop(t*1000,false):w.renderAt(t),fit, size,
    // Lottie goToAndStop receives milliseconds when isFrame=false.
    destroy:()=>{w.demo?.pause();w.anim?.pause();}};
}