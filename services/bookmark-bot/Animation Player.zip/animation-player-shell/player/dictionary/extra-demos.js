if (typeof CSS !== 'undefined' && CSS.registerProperty) {
  CSS.registerProperty({ name: '--motion-number', syntax: '<integer>', initialValue: '0', inherits: false });
}

export function renderExtra(entry, context) {
  const { add, animate, stage, duration, easing, rate, springFrames, interactive, signal } = context;
  const object = () => add('object');
  const sample = (compute, count = 81) => Array.from({ length: count }, (_, index) => compute(index / (count - 1)));

  function label(text, y) {
    const element = add('comparison-label');
    element.textContent = text;
    element.style.top = `calc(50% + ${y - 7}px)`;
  }

  function compare(topFrames, bottomFrames, options = {}) {
    [topFrames, bottomFrames].forEach((frames, index) => {
      const y = index === 0 ? -24 : 24;
      const shape = object();
      shape.style.width = '24px';
      shape.style.height = '24px';
      shape.style.top = `calc(50% + ${y - 12}px)`;
      animate(shape, frames, options[index] || {});
    });
  }

  function trace(path, dashed = true) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('viewBox', '0 0 200 120');
    svg.setAttribute('class', 'trace');
    const line = document.createElementNS(svg.namespaceURI, 'path');
    line.setAttribute('d', path);
    line.setAttribute('fill', 'none');
    line.setAttribute('stroke', 'currentColor');
    line.setAttribute('stroke-width', dashed ? '1' : '3');
    line.setAttribute('stroke-linecap', 'round');
    if (dashed) line.setAttribute('stroke-dasharray', '3 5');
    svg.append(line);
    stage.append(svg);
    return line;
  }

  function drag(snap) {
    [-64, 0, 64].forEach((x) => {
      const ghost = add('ghost');
      ghost.style.transform = `translateX(${x}px)`;
    });
    const shape = object();
    shape.classList.add('interactive');
    shape.tabIndex = 0;
    shape.setAttribute('role', 'slider');
    shape.setAttribute('aria-label', 'Положение объекта по горизонтали');
    shape.setAttribute('aria-valuemin', '-64');
    shape.setAttribute('aria-valuemax', '64');
    shape.setAttribute('aria-valuenow', '0');
    let x = 0;
    let startX = 0;
    let origin = 0;
    let held = false;
    let active;
    function set(value) {
      x = Math.max(-64, Math.min(64, value));
      shape.style.transform = `translateX(${x}px)`;
      shape.setAttribute('aria-valuenow', String(Math.round(x)));
    }
    function settle() {
      if (!held) return;
      held = false;
      if (snap) {
        const next = Math.round(x / 64) * 64;
        active = animate(shape, [{ transform: `translateX(${x}px)` }, { transform: `translateX(${next}px)` }]);
        set(next);
      }
    }
    shape.addEventListener('pointerdown', (event) => {
      const matrix = new DOMMatrixReadOnly(getComputedStyle(shape).transform);
      active?.cancel();
      set(matrix.m41);
      held = true;
      startX = event.clientX;
      origin = x;
      shape.setPointerCapture(event.pointerId);
    }, { signal });
    shape.addEventListener('pointermove', (event) => {
      if (held) set(origin + event.clientX - startX);
    }, { signal });
    shape.addEventListener('pointerup', settle, { signal });
    shape.addEventListener('pointercancel', settle, { signal });
    shape.addEventListener('keydown', (event) => {
      if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
      event.preventDefault();
      active?.cancel();
      set(x + (event.key === 'ArrowLeft' ? -1 : 1) * (snap ? 64 : 8));
    }, { signal });
  }

  switch (entry.id) {
    case 'opacity': animate(object(), [{ opacity: 1 }, { opacity: .25 }]); break;
    case 'blur-in': animate(object(), [{ filter: 'blur(12px)', opacity: 0 }, { filter: 'blur(0)', opacity: 1 }]); break;
    case 'blur-out': animate(object(), [{ filter: 'blur(0)', opacity: 1 }, { filter: 'blur(12px)', opacity: 0 }]); break;
    case 'pop-in': animate(object(), [
      { transform: 'scale(.7)', opacity: 0, offset: 0 },
      { transform: 'scale(1.08)', opacity: 1, offset: .7 },
      { transform: 'scale(1)', opacity: 1, offset: 1 },
    ]); break;
    case 'arc': {
      trace('M36 76 Q100 -52 164 76');
      animate(object(), sample((t) => ({ transform: `translate(${-64 + 128 * t}px, ${16 - 256 * t * (1 - t)}px)` })));
      break;
    }
    case 'orbit': {
      add('orbit-track');
      const shape = add('object circle');
      shape.style.width = '24px';
      shape.style.height = '24px';
      animate(shape, sample((t) => ({
        transform: `translate(${46 * Math.cos(t * Math.PI * 2)}px, ${46 * Math.sin(t * Math.PI * 2)}px)`,
      })), { easing: 'linear' });
      break;
    }
    case 'motion-path': {
      trace('M36 76 C65 -8 135 128 164 44');
      animate(object(), sample((t) => {
        const v = 1 - t;
        const x = v ** 3 * 36 + 3 * v ** 2 * t * 65 + 3 * v * t ** 2 * 135 + t ** 3 * 164;
        const y = v ** 3 * 76 - 3 * v ** 2 * t * 8 + 3 * v * t ** 2 * 128 + t ** 3 * 44;
        return { transform: `translate(${x - 100}px, ${y - 60}px)` };
      }));
      break;
    }
    case 'squash-stretch': animate(add('object circle'), [
      { transform: 'scale(1)' }, { transform: 'scale(1.25,.8)' }, { transform: 'scale(1)' },
    ]); break;
    case 'anticipation': animate(object(), [
      { transform: 'translateX(0)', offset: 0 },
      { transform: 'translateX(-12px)', offset: .25 },
      { transform: 'translateX(64px)', offset: 1 },
    ]); break;
    case 'follow-through': {
      const body = object();
      const dot = add('object circle', body);
      Object.assign(dot.style, { width: '12px', height: '12px', left: '18px', top: '18px', background: 'var(--inverse)' });
      animate(body, [
        { transform: 'translateX(-64px)', offset: 0 },
        { transform: 'translateX(64px)', offset: .65 },
        { transform: 'translateX(64px)', offset: 1 },
      ], { easing: 'ease-out' });
      animate(dot, [
        { transform: 'translateX(0)', offset: 0 },
        { transform: 'translateX(0)', offset: .5 },
        { transform: 'translateX(8px)', offset: .75 },
        { transform: 'translateX(0)', offset: 1 },
      ]);
      break;
    }
    case 'loop': animate(object(), [{ transform: 'rotate(0)' }, { transform: 'rotate(360deg)' }], { easing: 'linear' }); break;
    case 'ping-pong': animate(object(), [-64, 64, -64].map((x) => ({ transform: `translateX(${x}px)`, easing })), { easing: 'linear' }); break;
    case 'hold': animate(object(), [
      { transform: 'translateX(-64px)', offset: 0, easing },
      { transform: 'translateX(0)', offset: .25 },
      { transform: 'translateX(0)', offset: .75, easing },
      { transform: 'translateX(64px)', offset: 1 },
    ], { easing: 'linear' }); break;
    case 'duration': {
      const frames = [{ transform: 'translateX(-64px)' }, { transform: 'translateX(64px)' }];
      compare(frames, frames, { 0: { duration: 600 } });
      label('600', -24);
      label(String(duration), 24);
      return Math.max(600, duration);
    }
    case 'playback-rate': {
      const frames = [{ transform: 'translateX(-64px)' }, { transform: 'translateX(64px)' }];
      compare(frames, frames);
      const animation = stage.getAnimations({ subtree: true }).at(-1);
      animation.playbackRate = rate * .5;
      label('1×', -24);
      label('.5×', 24);
      return duration * 2;
    }
    case 'distance': {
      compare(
        [{ transform: 'translateX(-64px)' }, { transform: 'translateX(64px)' }],
        [{ transform: 'translateX(-32px)' }, { transform: 'translateX(32px)' }],
      );
      break;
    }
    case 'amplitude': {
      const left = object();
      const right = object();
      animate(left, [20, -20, 20].map((y) => ({ transform: `translate(-40px,${y}px)` })));
      animate(right, [10, -10, 10].map((y) => ({ transform: `translate(40px,${y}px)` })));
      break;
    }
    case 'damping':
      compare(springFrames({ damping: 12 }), springFrames({ damping: 26 }), { 0: { easing: 'linear' }, 1: { easing: 'linear' } });
      label('12', -24);
      label('26', 24);
      break;
    case 'stiffness':
      compare(springFrames({ stiffness: 90 }), springFrames({ stiffness: 240 }), { 0: { easing: 'linear' }, 1: { easing: 'linear' } });
      label('90', -24);
      label('240', 24);
      break;
    case 'typewriter': {
      const text = add('text-sample');
      text.textContent = 'ЗАПРОС';
      animate(text, [{ clipPath: 'inset(0 100% 0 0)' }, { clipPath: 'inset(0 0% 0 0)' }], { easing: 'steps(6,end)' });
      break;
    }
    case 'word-stagger': {
      const group = add('word-group');
      ['Один', 'запрос', 'готов'].forEach((word, index) => {
        const element = add('word', group);
        element.textContent = word;
        animate(element, [{ opacity: 0 }, { opacity: 1 }], { delay: index * 160 });
      });
      return duration + 320;
    }
    case 'counter':
      animate(add('counter'), [{ '--motion-number': '0' }, { '--motion-number': '8' }]);
      break;
    case 'line-draw': {
      const path = trace('M24 80 C60 80 50 20 100 40 S150 100 176 28', false);
      path.setAttribute('pathLength', '1');
      path.style.strokeDasharray = '1';
      animate(path, [{ strokeDashoffset: '1' }, { strokeDashoffset: '0' }]);
      break;
    }
    case 'drag':
    case 'snap':
      if (interactive) drag(entry.id === 'snap');
      else animate(object(), [{ transform: 'translateX(-40px)' }, { transform: 'translateX(40px)' }, { transform: `translateX(${entry.id === 'snap' ? 64 : 40}px)` }]);
      break;
    case 'inertia':
      animate(object(), sample((t) => ({ transform: `translateX(${-64 + 128 * (1 - Math.exp(-5 * t)) / (1 - Math.exp(-5))}px)` })), { easing: 'linear' });
      break;
    case 'circular-reveal':
      animate(object(), [{ clipPath: 'circle(0%)' }, { clipPath: 'circle(72%)' }]);
      break;
    case 'push': {
      const first = object();
      const second = object();
      second.style.color = 'var(--peach)';
      animate(first, [{ transform: 'translateX(0)' }, { transform: 'translateX(-48px)' }]);
      animate(second, [{ transform: 'translateX(48px)' }, { transform: 'translateX(0)' }]);
      stage.style.clipPath = 'inset(0 calc(50% - 24px))';
      break;
    }
    case 'reverse': {
      const frames = [
        { transform: 'translate(-64px,0) scale(.6)' },
        { transform: 'translate(0,-24px) scale(1)' },
        { transform: 'translate(64px,0) scale(.6)' },
      ];
      animate(object(), frames, { direction: 'reverse', easing: 'linear' });
      break;
    }
    case 'focus': {
      const group = add('group');
      for (let index = 0; index < 3; index++) {
        const shape = add('object small', group);
        if (index !== 1) animate(shape, [{ opacity: 1 }, { opacity: .2 }]);
      }
      break;
    }
    default: throw new Error(`Неизвестный пример: ${entry.id}`);
  }
  return duration;
}
