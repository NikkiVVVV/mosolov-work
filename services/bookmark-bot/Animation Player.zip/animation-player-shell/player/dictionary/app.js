import { entries, groups } from './data.js';
import { renderExtra } from './extra-demos.js';

const $ = (id) => document.getElementById(id);
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
let paused = reducedMotion.matches;
let inactive = false;
let activeGroup = 'all';
let selected = entries.find((entry) => entry.id === location.hash.slice(1)) || entries[0];
let detailDemo;
let selectedCard;
let copyTimer;
let backdrop;
const cardDemos = new Map();

const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (char) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[char]));

function springFrames({ stiffness = 180, damping = 12, mass = 1 } = {}) {
  // Unit-step response of an underdamped mass-spring system, sampled for WAAPI.
  const naturalFrequency = Math.sqrt(stiffness / mass);
  const decay = damping / (2 * mass);
  const frequency = Math.sqrt(naturalFrequency ** 2 - decay ** 2);
  return Array.from({ length: 121 }, (_, index) => {
    const time = (index / 120) * 1.6;
    const progress = 1 - Math.exp(-decay * time) * (
      Math.cos(frequency * time) + decay / frequency * Math.sin(frequency * time)
    );
    return { transform: `translateX(${-64 + 128 * progress}px)` };
  });
}

function bounceProgress(value) {
  const factor = 7.5625;
  const divisor = 2.75;
  if (value < 1 / divisor) return factor * value * value;
  if (value < 2 / divisor) return factor * (value -= 1.5 / divisor) * value + 0.75;
  if (value < 2.5 / divisor) return factor * (value -= 2.25 / divisor) * value + 0.9375;
  return factor * (value -= 2.625 / divisor) * value + 0.984375;
}

function makeDemo(host, entry, options = {}) {
  const stage = document.createElement('div');
  stage.className = 'stage';
  const group = groups.find((item) => item.id === entry.group);
  stage.style.setProperty('--motion-color', `var(--${group.color})`);
  host.replaceChildren(stage);
  let animations = [];
  let timer;
  let events = new AbortController();
  let visible = true;
  let runDuration = entry.ms;
  const duration = options.duration || entry.ms;
  const easing = options.easing || 'ease-out';
  const rate = options.rate || 1;

  if (options.interactive && entry.interaction) {
    const hint = document.createElement('div');
    hint.className = 'interaction-hint';
    hint.textContent = entry.interaction;
    host.append(hint);
  }

  function add(className, parent = stage) {
    const element = document.createElement('div');
    element.className = className;
    parent.append(element);
    return element;
  }

  function animate(element, frames, config = {}) {
    const animation = element.animate(frames, {
      duration, easing, fill: 'both', ...config,
    });
    animation.playbackRate = rate;
    animations.push(animation);
    if (paused || inactive) {
      animation.pause();
      animation.currentTime = options.interactive ? 0 : duration * 0.65;
    }
    return animation;
  }

  function move(frames, config = {}) {
    return animate(add('object'), frames, config);
  }

  function horizontal(curve = easing, extra = {}) {
    add('ghost').style.transform = 'translateX(64px)';
    move([{ transform: 'translateX(-64px)' }, { transform: 'translateX(64px)' }], { easing: curve, ...extra });
  }

  function renderScroll() {
    const scrollBox = document.createElement('div');
    scrollBox.className = 'scroll-box';
    scrollBox.tabIndex = 0;
    scrollBox.setAttribute('aria-label', 'Прокрутите пример анимации');
    const content = add('scroll-content', scrollBox);
    const note = document.createElement('span');
    note.className = 'scroll-note';
    note.textContent = 'Прокрути вниз ↓';
    content.append(note);
    stage.append(scrollBox);
    if (entry.id === 'scroll-reveal') {
      const shape = add('object', content);
      shape.style.opacity = '0';
      let entered = false;
      scrollBox.addEventListener('scroll', () => {
        const threshold = shape.offsetTop - scrollBox.clientHeight + 24;
        if (!entered && scrollBox.scrollTop > threshold) {
          entered = true;
          animate(shape, [{ opacity: 0, transform: 'translateY(24px)' }, { opacity: 1, transform: 'translateY(0)' }]);
        }
      }, { signal: events.signal });
    } else if (entry.id === 'scroll-driven') {
      const progress = add('scroll-progress');
      progress.style.position = 'absolute';
      progress.style.transform = 'scaleX(0)';
      scrollBox.addEventListener('scroll', () => {
        progress.style.transform = `scaleX(${scrollBox.scrollTop / (content.offsetHeight - scrollBox.clientHeight)})`;
      }, { signal: events.signal });
    } else {
      const viewport = add('parallax-viewport', content);
      const back = add('object layer-back', viewport);
      const front = add('object', viewport);
      scrollBox.addEventListener('scroll', () => {
        const progress = scrollBox.scrollTop / (content.offsetHeight - scrollBox.clientHeight);
        back.style.transform = `translateY(${-30 * progress}px)`;
        front.style.transform = `translateY(${-100 * progress}px)`;
      }, { signal: events.signal });
    }
  }

  function renderInteraction() {
    if (entry.id === 'ripple') {
      const target = add('ripple-target');
      target.tabIndex = 0;
      target.setAttribute('role', 'button');
      target.setAttribute('aria-label', 'Показать волну нажатия');
      function ripple(x, y) {
        const circle = add('ripple-circle', target);
        circle.style.left = `${x - 24}px`;
        circle.style.top = `${y - 24}px`;
        const animation = animate(circle, [{ transform: 'scale(0)', opacity: 0.6 }, { transform: 'scale(5)', opacity: 0 }]);
        animation.finished.then(() => circle.remove()).catch(() => {});
      }
      target.addEventListener('pointerdown', (event) => {
        const bounds = target.getBoundingClientRect();
        ripple(event.clientX - bounds.left, event.clientY - bounds.top);
      }, { signal: events.signal });
      target.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          ripple(80, 40);
        }
      }, { signal: events.signal });
      return;
    }
    const target = document.createElement('button');
    target.className = 'object interactive';
    target.setAttribute('aria-label', entry.ru);
    stage.append(target);
    let activeAnimation;
    function change(to) {
      const from = getComputedStyle(target);
      const start = { transform: from.transform, height: from.height };
      activeAnimation?.cancel();
      activeAnimation = animate(target, [start, to]);
    }
    if (entry.id === 'hover') {
      const enter = () => change({ transform: 'translateY(-8px) scale(1.06)' });
      const leave = () => change({ transform: 'translateY(0) scale(1)' });
      target.addEventListener('pointerenter', enter, { signal: events.signal });
      target.addEventListener('pointerleave', leave, { signal: events.signal });
      target.addEventListener('focus', enter, { signal: events.signal });
      target.addEventListener('blur', leave, { signal: events.signal });
      target.addEventListener('click', enter, { signal: events.signal });
    } else if (entry.id === 'press') {
      const down = () => change({ transform: 'scale(.9)' });
      const up = () => change({ transform: 'scale(1)' });
      target.addEventListener('pointerdown', (event) => {
        target.setPointerCapture(event.pointerId);
        down();
      }, { signal: events.signal });
      target.addEventListener('pointerup', up, { signal: events.signal });
      target.addEventListener('pointercancel', up, { signal: events.signal });
      target.addEventListener('keydown', (event) => {
        if (event.key === ' ' || event.key === 'Enter') down();
      }, { signal: events.signal });
      target.addEventListener('keyup', up, { signal: events.signal });
      target.addEventListener('blur', up, { signal: events.signal });
    } else {
      target.style.width = '144px';
      target.style.height = '32px';
      target.style.overflow = 'hidden';
      target.setAttribute('aria-expanded', 'false');
      const lines = add('collapse-content', target);
      for (let index = 0; index < 4; index++) add('collapse-line', lines);
      let expanded = false;
      target.addEventListener('click', () => {
        expanded = !expanded;
        target.setAttribute('aria-expanded', String(expanded));
        change({ height: expanded ? '112px' : '32px' });
      }, { signal: events.signal });
    }
  }

  function render() {
    const fadeFrames = [{ opacity: 0 }, { opacity: 1 }];
    const riseFrames = [{ opacity: 0, transform: 'translateY(24px)' }, { opacity: 1, transform: 'translateY(0)' }];
    switch (entry.id) {
      case 'fade-in': move(fadeFrames); break;
      case 'fade-out': move([...fadeFrames].reverse()); break;
      case 'slide-in': move([{ transform: `translateX(${stage.clientWidth / 2 + 48}px)` }, { transform: 'translateX(0)' }]); break;
      case 'slide-out': move([{ transform: 'translateX(0)' }, { transform: `translateX(${-stage.clientWidth / 2 - 48}px)` }]); break;
      case 'scale-in': move([{ transform: 'scale(0)' }, { transform: 'scale(1)' }]); break;
      case 'scale-out': move([{ transform: 'scale(1)' }, { transform: 'scale(0)' }]); break;
      case 'translate': horizontal(); break;
      case 'scale': move([{ transform: 'scale(.6)' }, { transform: 'scale(1.25)' }]); break;
      case 'rotate': move([{ transform: 'rotate(0)' }, { transform: 'rotate(180deg)' }]); break;
      case 'skew': move([{ transform: 'skewX(0)' }, { transform: 'skewX(24deg)' }]); break;
      case 'flip': {
        const card = add('object flip');
        const front = add('face', card);
        front.textContent = 'A';
        const back = add('face back', card);
        back.textContent = 'B';
        animate(card, [{ transform: 'rotateY(0)' }, { transform: 'rotateY(180deg)' }]);
        break;
      }
      case 'origin': {
        add('dot');
        const object = add('object');
        object.style.transformOrigin = 'top left';
        animate(object, [{ transform: 'scale(0)' }, { transform: 'scale(1)' }]);
        break;
      }
      case 'crossfade': {
        const first = add('object');
        const second = add('object circle');
        second.style.color = 'var(--peach)';
        animate(first, [...fadeFrames].reverse());
        animate(second, fadeFrames);
        break;
      }
      case 'reveal': move([{ clipPath: 'inset(0 100% 0 0)' }, { clipPath: 'inset(0 0% 0 0)' }]); break;
      case 'morph': move([{ borderRadius: '12px' }, { borderRadius: '50%' }]); break;
      case 'layout': {
        const group = add('group');
        const first = add('object small', group);
        const middle = add('object small', group);
        const last = add('object small', group);
        const initial = [first, last].map((element) => element.getBoundingClientRect().left);
        middle.remove();
        [first, last].forEach((element, index) => {
          const shift = initial[index] - element.getBoundingClientRect().left;
          animate(element, [{ transform: `translateX(${shift}px)` }, { transform: 'translateX(0)' }]);
        });
        break;
      }
      case 'shared': {
        add('panel');
        const shape = add('object');
        animate(shape, [
          { transform: 'translate(-64px, 28px)', width: '32px', height: '32px' },
          { transform: 'translate(32px, 0)', width: '96px', height: '72px' },
        ]);
        break;
      }
      case 'pulse': move([{ transform: 'scale(1)' }, { transform: 'scale(1.14)' }, { transform: 'scale(1)' }]); break;
      case 'shake': move([0, -12, 12, -8, 8, 0].map((x) => ({ transform: `translateX(${x}px)` }))); break;
      case 'bounce': {
        add('track');
        const ball = add('object circle');
        animate(ball, Array.from({ length: 101 }, (_, index) => ({
          transform: `translateY(${-40 + 40 * bounceProgress(index / 100)}px)`,
        })), { easing: 'linear' });
        break;
      }
      case 'overshoot': horizontal('cubic-bezier(.34,1.56,.64,1)'); break;
      case 'float': move([10, -10, 10].map((y) => ({ transform: `translateY(${y}px)` }))); break;
      case 'stagger':
      case 'sequence':
      case 'parallel': {
        const group = add('group');
        const count = entry.id === 'stagger' ? 4 : 3;
        const interval = entry.id === 'stagger' ? 120 : entry.id === 'sequence' ? duration : 0;
        for (let index = 0; index < count; index++) {
          animate(add('object small', group), entry.id === 'sequence' ? fadeFrames : riseFrames, { delay: index * interval });
        }
        runDuration = duration + (count - 1) * interval;
        break;
      }
      case 'delay': horizontal(easing, { delay: 800 }); runDuration = duration + 800; break;
      case 'keyframes': move([
        { transform: 'translate(-64px,16px)' },
        { transform: 'translate(0,-28px)' },
        { transform: 'translate(64px,16px)' },
      ]); break;
      case 'steps': horizontal('steps(5,end)'); break;
      case 'linear': horizontal('linear'); break;
      case 'ease-in': horizontal('ease-in'); break;
      case 'ease-out': horizontal('ease-out'); break;
      case 'ease-in-out': horizontal('ease-in-out'); break;
      case 'spring': move(springFrames(), { duration: 1600, easing: 'linear' }); runDuration = 1600; break;
      case 'hover':
      case 'press':
      case 'ripple':
      case 'collapse': {
        if (options.interactive) {
          renderInteraction();
          return;
        }
        if (entry.id === 'hover') move([{ transform: 'translateY(0) scale(1)' }, { transform: 'translateY(-8px) scale(1.06)' }]);
        if (entry.id === 'press') move([{ transform: 'scale(1)' }, { transform: 'scale(.9)' }, { transform: 'scale(1)' }]);
        if (entry.id === 'collapse') move([{ height: '32px', width: '112px' }, { height: '88px', width: '112px' }]);
        if (entry.id === 'ripple') {
          const target = add('ripple-target');
          animate(add('object circle', target), [{ transform: 'scale(0)', opacity: .6 }, { transform: 'scale(5)', opacity: 0 }]);
        }
        break;
      }
      case 'scroll-reveal':
      case 'parallax':
      case 'scroll-driven': {
        if (options.interactive) {
          renderScroll();
          return;
        }
        if (entry.id === 'scroll-reveal') move(riseFrames);
        if (entry.id === 'scroll-driven') {
          const bar = add('object');
          bar.style.width = '144px';
          bar.style.height = '8px';
          bar.style.transformOrigin = 'left';
          animate(bar, [{ transform: 'scaleX(0)' }, { transform: 'scaleX(1)' }], { easing: 'linear' });
        }
        if (entry.id === 'parallax') {
          const back = add('object circle');
          back.style.opacity = '.25';
          back.style.width = '88px';
          back.style.height = '88px';
          animate(back, [{ transform: 'translateY(15px)' }, { transform: 'translateY(-15px)' }]);
          move([{ transform: 'translateY(40px)' }, { transform: 'translateY(-40px)' }]);
        }
        break;
      }
      default:
        runDuration = renderExtra(entry, {
          add, animate, stage, duration, easing, rate, springFrames,
          interactive: options.interactive,
          signal: events.signal,
        }) || duration;
    }
  }

  const manual = options.interactive && Boolean(entry.interaction);
  function schedule() {
    clearTimeout(timer);
    const gap = ['float', 'loop', 'ping-pong', 'orbit'].includes(entry.id) ? 0 : entry.id === 'pulse' ? 600 : 850;
    if (!paused && !inactive && visible && !manual) timer = setTimeout(play, (runDuration + gap) / rate);
  }

  function play() {
    clearTimeout(timer);
    animations.forEach((animation) => animation.cancel());
    animations = [];
    events.abort();
    events = new AbortController();
    stage.replaceChildren();
    render();
    schedule();
  }

  const controller = {
    play,
    setPaused() {
      clearTimeout(timer);
      animations.forEach((animation) => paused || inactive || !visible ? animation.pause() : animation.play());
      schedule();
    },
    setVisible(value) {
      visible = value;
      this.setPaused();
    },
    destroy() {
      clearTimeout(timer);
      events.abort();
      animations.forEach((animation) => animation.cancel());
    },
  };
  play();
  return controller;
}

const observer = new IntersectionObserver((records) => {
  records.forEach((record) => cardDemos.get(record.target)?.setVisible(record.isIntersecting));
}, { rootMargin: '60px' });

function renderGroups() {
  const counts = [{ id: 'all', title: 'Все движения' }, ...groups];
  $('categories').replaceChildren(...counts.map((group) => {
    const button = document.createElement('button');
    const count = group.id === 'all' ? entries.length : entries.filter((entry) => entry.group === group.id).length;
    button.innerHTML = `${escapeHtml(group.title)}<span>${count}</span>`;
    button.setAttribute('aria-pressed', String(group.id === activeGroup));
    button.onclick = () => {
      activeGroup = group.id;
      renderGroups();
      renderCards();
    };
    return button;
  }));
}

function renderCards() {
  observer.disconnect();
  cardDemos.forEach((demo) => demo.destroy());
  cardDemos.clear();
  const matches = entries.filter((entry) => activeGroup === 'all' || entry.group === activeGroup);
  $('cards').replaceChildren(...matches.map((entry) => {
    const card = document.createElement('button');
    card.className = 'card';
    card.dataset.id = entry.id;
    card.setAttribute('aria-pressed', String(entry.id === selected.id));
    card.setAttribute('aria-label', `${entry.name} — ${entry.ru}. Открыть пример и промпт`);
    const preview = document.createElement('div');
    preview.setAttribute('aria-hidden', 'true');
    const info = document.createElement('div');
    info.className = 'card-info';
    info.innerHTML = `<strong>${escapeHtml(entry.name)}</strong><span>${escapeHtml(entry.ru)}</span>`;
    card.append(preview, info);
    card.onclick = () => selectEntry(entry, card);
    return card;
  }));
  $('cards').querySelectorAll('.card').forEach((card) => {
    const entry = entries.find((item) => item.id === card.dataset.id);
    cardDemos.set(card, makeDemo(card.firstElementChild, entry));
    observer.observe(card);
  });
}

function refreshPrompt() {
  $('duration-value').value = `${$('duration').value} мс`;
  $('prompt').value = selected.prompt
    .replaceAll('{duration}', $('duration').value)
    .replaceAll('{easing}', $('easing').value);
  $('copy').textContent = 'Копировать';
}

function renderDetailDemo() {
  detailDemo?.destroy();
  detailDemo = makeDemo($('detail-demo'), selected, {
    interactive: true,
    duration: Number($('duration').value),
    easing: $('easing').value,
  });
}

function selectEntry(entry, card, open = true) {
  selected = entry;
  selectedCard = card;
  $('detail-name').textContent = entry.name;
  $('description').textContent = entry.description;
  $('duration').value = entry.ms;
  $('easing').value = ['float', 'pulse', 'ping-pong'].includes(entry.id) ? 'ease-in-out' : 'ease-out';
  $('duration-control').hidden = entry.fixedDuration || ['spring', 'parallax', 'scroll-driven'].includes(entry.id);
  $('easing-control').hidden = entry.fixedEase || ['parallax', 'scroll-driven'].includes(entry.id);
  document.querySelectorAll('.card').forEach((element) => element.setAttribute('aria-pressed', String(element.dataset.id === entry.id)));
  refreshPrompt();
  renderDetailDemo();
  $('detail').scrollTop = 0;
  if (open) {
    history.replaceState(null, '', `#${entry.id}`);
    if (matchMedia('(max-width: 900px)').matches) openDetail();
  }
}

function openDetail() {
  $('detail').classList.add('open');
  $('detail').setAttribute('role', 'dialog');
  $('detail').setAttribute('aria-modal', 'true');
  backdrop?.remove();
  backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  backdrop.onclick = closeDetail;
  document.body.append(backdrop);
  document.body.style.overflow = 'hidden';
  $('detail').focus({ preventScroll: true });
}

function closeDetail() {
  $('detail').classList.remove('open');
  $('detail').removeAttribute('role');
  $('detail').removeAttribute('aria-modal');
  backdrop?.remove();
  backdrop = null;
  document.body.style.overflow = '';
  selectedCard?.focus();
}

async function copyPrompt() {
  const text = $('prompt').value;
  let copied = false;
  try {
    await navigator.clipboard.writeText(text);
    copied = true;
  } catch {
    const input = document.createElement('textarea');
    input.value = text;
    input.style.position = 'fixed';
    input.style.opacity = '0';
    document.body.append(input);
    input.select();
    copied = document.execCommand('copy');
    input.remove();
  }
  if (!copied) {
    $('prompt').focus();
    $('prompt').select();
  }
  const message = copied ? 'Скопировано' : 'Выделено — нажми ⌘C / Ctrl+C';
  $('copy').textContent = message;
  $('status').textContent = message;
  clearTimeout(copyTimer);
  copyTimer = setTimeout(() => { $('copy').textContent = 'Копировать'; }, 2200);
}

function updatePlayback() {
  cardDemos.forEach((demo) => demo.setPaused());
  detailDemo?.setPaused();
}

$('duration').addEventListener('input', () => { refreshPrompt(); renderDetailDemo(); });
$('easing').addEventListener('change', () => { refreshPrompt(); renderDetailDemo(); });
$('copy').onclick = copyPrompt;
$('close-detail').onclick = closeDetail;
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && backdrop) closeDetail();
  if (event.key === 'Tab' && backdrop) {
    const focusable = [...$('detail').querySelectorAll('a,button,input,select,[tabindex="0"]')]
      .filter((element) => element.getClientRects().length);
    const first = focusable[0];
    const last = focusable.at(-1);
    if (event.shiftKey && (document.activeElement === first || document.activeElement === $('detail'))) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
});
matchMedia('(min-width: 901px)').addEventListener('change', (event) => {
  if (event.matches && backdrop) closeDetail();
});

window.addEventListener('message', (event) => {
  if (event.origin !== location.origin || event.source !== parent || event.data?.type !== 'dictionary-state') return;
  document.documentElement.dataset.theme = event.data.theme === 'dark' ? 'dark' : 'light';
  inactive = !event.data.active;
  updatePlayback();
});
if (parent !== window) parent.postMessage({ type: 'dictionary-ready' }, location.origin);
renderGroups();
renderCards();
selectEntry(selected, null, false);
updatePlayback();
