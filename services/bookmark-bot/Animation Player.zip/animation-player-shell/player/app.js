import {projects} from './registry.js';
import {connect, easings} from './adapters.js';
import {createLayout} from './layout.js';
const params=new URLSearchParams(location.search);
const cleanPreview=params.has('preview');

const $=id=>document.getElementById(id);
const frame=$('scene');
function sameOriginScene(url){if(url.origin!==location.origin)throw Error('Сцена должна находиться в этой папке.');}
const requestedProject=new URLSearchParams(location.search).get('animation');
let project=projects.find(p=>p.id===requestedProject)||projects[0],version,adapter=null,selected=0,time=0,playing=false,speed=1;
let loadToken=0,raf=0,lastTick=0;
const storageKey=()=>`animation-player-shell:simple:1:${project.id}:${version.id}`;

function readSettings(){try{return JSON.parse(localStorage.getItem(storageKey()));}catch{return null;}}
function validSettings(s,count){return Array.isArray(s)&&s.length===count&&s.every(row=>Number.isFinite(row.duration)&&row.duration>=200&&row.duration<=4000&&Number.isFinite(row.fade)&&row.fade>=0&&row.fade<=row.duration&&row.easing in easings);}
function save(){if(adapter?.editable){try{localStorage.setItem(storageKey(),JSON.stringify(adapter.settings.map(({duration,fade,easing})=>({duration,fade,easing}))));}catch{/* Preview still works without storage. */}}}

function buildVersions(){
 $('versions').replaceChildren();
 for(const v of project.versions){
  const b=document.createElement('button');b.dataset.id=v.id;b.setAttribute('aria-pressed','false');
  const label=document.createElement('b');label.textContent=v.label;
  const title=document.createElement('span');title.textContent=v.title;
  b.append(label,title);b.onclick=()=>load(v);$('versions').append(b);
 }
}
async function load(v,{preservePosition=false}={}){
 const previousTime=preservePosition?time:0,wasPlaying=preservePosition&&playing;
 const token=++loadToken;pause();save();adapter?.destroy();adapter=null;window.studioState=null;version=v;setSelection(false);readPlacement();selected=0;time=0;
 for(const b of $('versions').children)b.setAttribute('aria-pressed',String(b.dataset.id===v.id));
 $('play').disabled=true;$('stop').disabled=true;
 $('loading').textContent='Загружаем…';$('loading').hidden=false;$('scrub').disabled=true;$('scenes').replaceChildren();
 $('reference-analysis').hidden=typeof v.analysis!=='string';
 $('stage').dataset.version=v.id;
 const analysisPath=typeof v.analysis==='string'?v.analysis:null;
 if(analysisPath&&$('reference-analysis-body').dataset.source!==analysisPath){
  const body=$('reference-analysis-body');body.dataset.source=analysisPath;body.textContent='Загружаем разбор…';
  fetch(analysisPath).then(r=>{if(!r.ok)throw Error('report');return r.text();}).then(html=>{if(body.dataset.source===analysisPath)body.innerHTML=html;}).catch(()=>{if(body.dataset.source===analysisPath){body.textContent='Не удалось загрузить разбор. Обновите страницу.';delete body.dataset.source;}});
 }
 const file=theme==='dark'&&v.dark?v.dark:v.file;
 const url=new URL(file,location.origin);sameOriginScene(url);url.searchParams.set('t','0');
 try{
  await new Promise((resolve,reject)=>{
   const timer=setTimeout(()=>reject(Error('Не удалось загрузить анимацию.')),18000);
   frame.onload=()=>{clearTimeout(timer);resolve();};frame.onerror=()=>{clearTimeout(timer);reject(Error('Не удалось загрузить анимацию.'));};frame.src=url.href;
  });
  if(token!==loadToken)return;
  const next=await connect(frame,v);
  if(token!==loadToken){next.destroy();return;}
  adapter=next;
  if(adapter.editable){const saved=readSettings();if(validSettings(saved,adapter.defaults.length))adapter.setSettings(adapter.defaults.map((s,i)=>({...s,...saved[i]})));}
  $('scrub').disabled=false;$('loading').hidden=true;$('play').disabled=false;$('stop').disabled=false;
  time=Math.min(previousTime,adapter.duration());selected=Math.max(0,adapter.steps.findLastIndex(s=>s.start<=time));
  buildScenes();fit();render();if(wasPlaying||cleanPreview)play();
 }catch(e){if(token!==loadToken)return;$('loading').textContent=e.message+'\nПопробуйте другую версию.';}
}
function fit(){productLayout.update(mode,theme);layoutAnimation();adapter?.fit(1);}
new ResizeObserver(fit).observe($('presentation'));
new ResizeObserver(()=>adapter?.fit(1)).observe($('animation-layer'));
function buildScenes(){
 $('scenes').replaceChildren();
 adapter.steps.forEach((s,i)=>{
  const b=document.createElement('button');b.dataset.scene=String(i);
  const title=document.createElement('span');title.textContent=s.title;b.append(title);
  b.onclick=()=>{selected=i;seek(s.start);};$('scenes').append(b);
 });
}
function updatePlayButton(){
 const label=playing?'Пауза':'Воспроизвести';$('play').setAttribute('aria-label',label);$('play').title=label;
 $('play').innerHTML=playing?'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 5h4v14H6ZM14 5h4v14h-4Z"/></svg>':'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14l11-7Z"/></svg>';
}
function pause(){playing=false;cancelAnimationFrame(raf);updatePlayButton();if(window.studioState)window.studioState.playing=false;}
function play(){
 if(!adapter)return;if(time>=adapter.duration())time=0;
 playing=true;lastTick=performance.now();updatePlayButton();render();raf=requestAnimationFrame(tick);
}
function tick(now){
 time+=Math.min((now-lastTick)/1000,.1)*speed;lastTick=now;
 const ended=time>=adapter.duration();
 if(ended)time=version.loop===false?adapter.duration():time%adapter.duration();
 const active=Math.max(0,adapter.steps.findLastIndex(s=>s.start<=time));
 if(active!==selected){selected=active;}
 render();if(ended&&version.loop===false){pause();return;}if(playing)raf=requestAnimationFrame(tick);
}
function seek(t){pause();if(!adapter)return;time=Math.max(0,Math.min(adapter.duration(),t));selected=Math.max(0,adapter.steps.findLastIndex(s=>s.start<=time));render();}
$('play').onclick=()=>playing?pause():play();
$('stop').onclick=()=>seek(0);
$('scrub').oninput=()=>seek(Number($('scrub').value));
$('speed').onchange=()=>{speed=Number($('speed').value);render();};
const format=n=>n.toLocaleString('ru-RU',{minimumFractionDigits:1,maximumFractionDigits:1});
function render(){
 if(!adapter)return;adapter.render(time);$('scrub').max=adapter.duration();$('scrub').value=time;$('scrub').style.setProperty('--progress',`${time/adapter.duration()*100}%`);$('time').textContent=`${format(time)} / ${format(adapter.duration())} с`;
 [...$('scenes').children].forEach((b,i)=>b.setAttribute('aria-pressed',String(i===selected)));
 window.studioState={version:version.id,time,duration:adapter.duration(),selected,playing,speed,editable:adapter.editable,theme,mode,placement:{...placement}};
}
function switchView(dictionary){
 pause();setSelection(false);$('animation-view').hidden=dictionary;$('dictionary-view').hidden=!dictionary;
 document.documentElement.dataset.view=dictionary?'dictionary':'animation';
 if(dictionary&&!$('dictionary-frame').hasAttribute('src'))$('dictionary-frame').src='./dictionary/?theme='+theme;
 syncDictionary();
 const url=new URL(location.href);if(dictionary)url.searchParams.set('view','dictionary');else url.searchParams.delete('view');history.replaceState(null,'',url);
 $('animation-tab').toggleAttribute('aria-current',!dictionary);$('dictionary-tab').toggleAttribute('aria-current',dictionary);
 if(dictionary){$('dictionary-tab').setAttribute('aria-current','page');}else{$('animation-tab').setAttribute('aria-current','page');requestAnimationFrame(fit);}
}
$('animation-tab').onclick=()=>switchView(false);$('dictionary-tab').onclick=()=>switchView(true);
function syncDictionary(){
 $('dictionary-frame').contentWindow?.postMessage({type:'dictionary-state',theme,active:!$('dictionary-view').hidden},location.origin);
}
window.addEventListener('message',event=>{
 if(event.origin===location.origin&&event.source===$('dictionary-frame').contentWindow&&event.data?.type==='dictionary-ready')syncDictionary();
});
document.addEventListener('keydown',e=>{
 if(e.defaultPrevented||e.target.matches('input,select,textarea,[contenteditable]')||$('animation-view').hidden)return;
 if(e.code==='Space'){e.preventDefault();playing?pause():play();}
 if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();seek(Math.round(time*60+(e.key==='ArrowLeft'?-1:1)*(e.shiftKey?10:1))/60);}
});
window.addEventListener('pagehide',()=>{pause();save();});

function preference(name,fallback){try{return localStorage.getItem('animation-player-shell:'+name)||fallback;}catch{return fallback;}}
let theme=(params.get('theme')||preference('theme','light'))==='dark'?'dark':'light';
const requestedMode=params.get('mode')||preference('mode','animation');
let mode=requestedMode==='mobile'||requestedMode==='layout'?'mobile':'animation';
function persistPreference(name,value){try{localStorage.setItem('animation-player-shell:'+name,value);}catch{}}
function applyTheme(){
 document.documentElement.dataset.theme=theme;productLayout.update(mode,theme);
 syncDictionary();
 $('theme-light').setAttribute('aria-pressed',String(theme==='light'));
 $('theme-dark').setAttribute('aria-pressed',String(theme==='dark'));
}
function setTheme(next){
 if(next===theme)return;theme=next;persistPreference('theme',theme);applyTheme();
 if(version?.dark)load(version,{preservePosition:true});else render();
}
function setMode(next){
 mode=next;setSelection(false);$('stage').dataset.mode=mode;
 $('mode-animation').setAttribute('aria-pressed',String(mode==='animation'));
 $('mode-mobile').setAttribute('aria-pressed',String(mode==='mobile'));
 productLayout.update(mode,theme);
 persistPreference('mode',mode);$('animation-layer').tabIndex=mode==='mobile'?0:-1;requestAnimationFrame(fit);render();
}
$('theme-light').onclick=()=>setTheme('light');$('theme-dark').onclick=()=>setTheme('dark');
$('mode-animation').onclick=()=>setMode('animation');$('mode-mobile').onclick=()=>setMode('mobile');
// Placement belongs to the preview, independently of animation timing.
let placement={x:.5,y:.5,scale:1},gesture=null;
const layer=$('animation-layer');
const productLayout=createLayout($('presentation'),()=>requestAnimationFrame(fit));
let placementSelected=false;
function setSelection(value){
 placementSelected=value&&mode==='mobile'&&!cleanPreview;
 $('animation-layer').classList.toggle('selected',placementSelected);
 $('resize-animation').hidden=!placementSelected;
 $('resize-animation').tabIndex=placementSelected?0:-1;
}
document.addEventListener('pointerdown',e=>{if(!layer.contains(e.target))setSelection(false);});
layer.addEventListener('focusin',()=>{if(mode==='mobile')setSelection(true);});
const placementKey=()=>`animation-player-shell:placement:1:${project.id}:${version.id}`;
function readPlacement(){
 placement={x:.5,y:.5,scale:1};
 try{const v=JSON.parse(localStorage.getItem(placementKey()));if(v&&Number.isFinite(v.x)&&Number.isFinite(v.y)&&Number.isFinite(v.scale))placement={x:Math.max(0,Math.min(1,v.x)),y:Math.max(0,Math.min(1,v.y)),scale:Math.max(.25,Math.min(2.5,v.scale))};}catch{}
 if(cleanPreview){for(const k of ['x','y']){const n=Number(params.get(k));if(params.has(k)&&Number.isFinite(n))placement[k]=Math.max(0,Math.min(1,n));}const s=Number(params.get('scale'));if(params.has('scale')&&Number.isFinite(s))placement.scale=Math.max(.25,Math.min(2.5,s));}
}
function savePlacement(){try{localStorage.setItem(placementKey(),JSON.stringify(placement));}catch{}}
function layoutAnimation(){
 const viewport=$('animation-viewport');
 if(mode!=='mobile'){
  viewport.hidden=false;viewport.style.cssText='';layer.hidden=false;layer.style.cssText='';layer.removeAttribute('role');layer.removeAttribute('aria-label');return;
 }
 const bounds=productLayout.animationBounds();
 viewport.hidden=!bounds;
 layer.hidden=!bounds;
 if(!bounds)return;
 Object.assign(viewport.style,{left:bounds.x+'px',top:bounds.y+'px',width:bounds.width+'px',height:bounds.height+'px'});
 const size=adapter?.size||[1440,1080];
 const width=Math.min(bounds.width,bounds.height*size[0]/size[1])*placement.scale;
 layer.style.width=width+'px';layer.style.height=width*size[1]/size[0]+'px';
 layer.style.left=placement.x*100+'%';layer.style.top=placement.y*100+'%';
 // Keep the grip reachable when the artwork extends beyond the phone screen.
 const screenWidth=bounds.width,screenHeight=bounds.height;
 const height=width*size[1]/size[0],left=placement.x*screenWidth-width/2,top=placement.y*screenHeight-height/2;
 const gripX=Math.max(16,Math.min(screenWidth-16,left+width));
 const gripY=Math.max(24,Math.min(screenHeight-24,top+height));
 $('resize-animation').style.left=(gripX-left-12)+'px';$('resize-animation').style.top=(gripY-top-12)+'px';

 layer.setAttribute('role','group');layer.setAttribute('aria-label','Анимация: перетащите для перемещения, потяните за угол для изменения размера');
}
layer.addEventListener('pointerdown',e=>{
 if(cleanPreview||mode!=='mobile'||!adapter||e.button!==0||gesture)return;
 e.preventDefault();setSelection(true);layer.focus({preventScroll:true});
 const box=layer.getBoundingClientRect(),screen=$('animation-viewport');
 gesture={id:e.pointerId,kind:e.target.closest('#resize-animation')?'resize':'move',x:e.clientX,y:e.clientY,initial:{...placement},width:box.width,height:box.height,screenWidth:screen.clientWidth,screenHeight:screen.clientHeight};
 layer.setPointerCapture(e.pointerId);layer.classList.add('manipulating');
});
layer.addEventListener('pointermove',e=>{
 if(!gesture||gesture.id!==e.pointerId)return;e.preventDefault();
 const dx=e.clientX-gesture.x,dy=e.clientY-gesture.y,start=gesture.initial;
 if(gesture.kind==='move'){
  placement.x=Math.max(0,Math.min(1,start.x+dx/gesture.screenWidth));
  placement.y=Math.max(0,Math.min(1,start.y+dy/gesture.screenHeight));
 }else{
  const vx=gesture.width/2,vy=gesture.height/2;
  placement.scale=Math.max(.25,Math.min(2.5,start.scale*(1+(dx*vx+dy*vy)/(vx*vx+vy*vy))));
 }
 fit();render();
});
function endGesture(e){if(!gesture||gesture.id!==e.pointerId)return;gesture=null;layer.classList.remove('manipulating');if(layer.hasPointerCapture(e.pointerId))layer.releasePointerCapture(e.pointerId);savePlacement();}
layer.addEventListener('pointerup',endGesture);layer.addEventListener('pointercancel',endGesture);layer.addEventListener('lostpointercapture',endGesture);
layer.addEventListener('keydown',e=>{
 if(e.key==='Escape'){setSelection(false);layer.blur();return;}
 if(mode!=='mobile'||!adapter||!placementSelected)return;
 if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','+','=','-'].includes(e.key))return;
 e.preventDefault();const step=e.shiftKey?10:1;
 if(e.target===$('resize-animation')||['+','=','-'].includes(e.key)){
  const direction=['ArrowLeft','ArrowDown','-'].includes(e.key)?-1:1;
  placement.scale=Math.max(.25,Math.min(2.5,placement.scale+direction*.05*step));
 }else{
  if(e.key==='ArrowLeft'||e.key==='ArrowRight')placement.x=Math.max(0,Math.min(1,placement.x+(e.key==='ArrowRight'?step:-step)/$('animation-viewport').clientWidth));
  else placement.y=Math.max(0,Math.min(1,placement.y+(e.key==='ArrowDown'?step:-step)/$('animation-viewport').clientHeight));
 }
 fit();render();savePlacement();
});
applyTheme();setMode(mode);


buildVersions();load(project.versions.find(v=>v.id===params.get('version'))||project.versions[0]);
if(params.get('view')==='dictionary'&&!cleanPreview)switchView(true);
$('phone-preview').onclick=async()=>{
 const dialog=$('phone-dialog');$('phone-link').textContent='Готовим ссылку…';$('phone-link').removeAttribute('href');$('phone-qr').hidden=true;dialog.showModal();
 try{
  const network=await fetch('/api/network').then(r=>{if(!r.ok)throw Error();return r.json();});
  const link=new URL('/',network.origin);link.searchParams.set('preview','1');link.searchParams.set('animation',project.id);link.searchParams.set('version',version.id);link.searchParams.set('theme',theme);link.searchParams.set('mode',mode);
  if(mode==='mobile')for(const [k,v] of Object.entries(placement))link.searchParams.set(k,String(Number(v.toFixed(4))));
  $('phone-link').href=link.href;$('phone-link').textContent=link.href;$('phone-qr').src='/api/qr.svg?'+link.searchParams;$('phone-qr').hidden=false;$('phone-help').textContent='Подключите телефон к той же Wi-Fi-сети.';
 }catch{$('phone-link').textContent='Не удалось получить локальный адрес.';$('phone-help').textContent='Проверьте подключение компьютера к Wi-Fi и запущенный сервер.';}
};
$('close-phone-dialog').onclick=()=>$('phone-dialog').close();
$('phone-dialog').addEventListener('click',e=>{if(e.target===$('phone-dialog')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.target.close();}});

// Every listed version uses the same complete export catalog.
$('save-animation').onclick=async()=>{
 pause();
 const requestedVersion=version,requestedTheme=theme;
 $('save-version').textContent=`${requestedVersion.label} · ${requestedVersion.title}`;
 $('save-files').textContent='Загружаем файлы…';$('save-dialog').showModal();
 try{
  const response=await fetch('/exports/catalog.json',{cache:'no-store'});
  if(!response.ok)throw Error('catalog');
  const catalog=await response.json();
  const exportTheme=requestedVersion.dark?requestedTheme:'light';
  const files=catalog.versions.find(v=>v.id===requestedVersion.id&&v.theme===exportTheme);
  if(!files||!files.video||!files.json||!files.html)throw Error('incomplete');
  const links=[];
  for(const [key,label,detail,extension] of [
   ['video','Скачать видео','MP4','mp4'],
   ['json','Скачать JSON',files.jsonKind==='raster'?'Lottie · растровая анимация':'Lottie','json'],
   ['html','Скачать HTML','Самостоятельный файл','html']
  ]){
   const a=document.createElement('a');a.href=files[key];a.download=`${requestedVersion.id}-${exportTheme}.${extension}`;
   const title=document.createElement('span');title.textContent=label;
   const subtitle=document.createElement('small');subtitle.textContent=detail;a.append(title,subtitle);links.push(a);
  }
  $('save-files').replaceChildren(...links);
 }catch{$('save-files').textContent='Не удалось загрузить файлы. Обновите страницу и попробуйте снова.';}
};
$('close-save-dialog').onclick=()=>$('save-dialog').close();
$('save-dialog').addEventListener('click',e=>{
 if(e.target!==e.currentTarget)return;
 const r=e.target.getBoundingClientRect();
 if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.target.close();
});
