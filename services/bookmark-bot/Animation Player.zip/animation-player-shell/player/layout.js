export function createLayout(presentation,onChange){
 const screen=document.createElement('div');screen.className='layout-screen shell-mockup';screen.hidden=true;
 screen.innerHTML=`<div class="layout-status" aria-hidden="true"><b>9:41</b><div class="layout-island"></div><svg class="layout-signals" viewBox="0 0 76 16"><g fill="currentColor"><rect x="0" y="10" width="3" height="6" rx="1"/><rect x="5" y="7" width="3" height="9" rx="1"/><rect x="10" y="4" width="3" height="12" rx="1"/><rect x="15" y="1" width="3" height="15" rx="1"/></g><g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M26 5q8-7 16 0M29 8q5-4 10 0M32 11q2-2 4 0"/><rect x="50" y="3" width="22" height="11" rx="3"/></g><g fill="currentColor"><circle cx="34" cy="14" r="1.2"/><rect x="52" y="5" width="18" height="7" rx="1"/><rect x="74" y="6" width="2" height="5" rx="1"/></g></svg></div><div class="shell-animation" aria-label="Область анимации"></div><div class="layout-home" aria-hidden="true"></div>`;
 presentation.append(screen);
 const slot=screen.querySelector('.shell-animation');
 let active=false;
 return {
  update(mode){
   active=mode==='mobile';screen.hidden=!active;
   if(active){const ratio=Math.min(presentation.clientWidth/375,presentation.clientHeight/812);if(ratio>0)screen.style.setProperty('--layout-fit',ratio);}
  },
  animationBounds(){
   if(!active)return null;
   const bounds=slot.getBoundingClientRect(),parent=presentation.getBoundingClientRect();
   return{x:bounds.left-parent.left-presentation.clientLeft,y:bounds.top-parent.top-presentation.clientTop,width:bounds.width,height:bounds.height};
  }
 };
}
