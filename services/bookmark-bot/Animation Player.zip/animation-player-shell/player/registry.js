export const projects = [
  {
    "id": "example",
    "title": "Пример анимации",
    "versions": [
      {
        "id": "demo-v2",
        "label": "V2",
        "title": "Плавнее",
        "file": "/examples/demo-v2/scene.html?theme=light",
        "dark": "/examples/demo-v2/scene.html?theme=dark",
        "adapter": "lottie",
        "loop": false,
        "steps": [
          [
            0,
            "Появление"
          ],
          [
            1.0,
            "Пауза"
          ],
          [
            2.7,
            "Исчезновение"
          ]
        ]
      },
      {
        "id": "demo-v1",
        "label": "V1",
        "title": "Быстрее",
        "file": "/examples/demo-v1/scene.html?theme=light",
        "dark": "/examples/demo-v1/scene.html?theme=dark",
        "adapter": "lottie",
        "loop": false,
        "steps": [
          [
            0,
            "Появление"
          ],
          [
            0.6,
            "Пауза"
          ],
          [
            2.0,
            "Исчезновение"
          ]
        ]
      }
    ]
  }
];
